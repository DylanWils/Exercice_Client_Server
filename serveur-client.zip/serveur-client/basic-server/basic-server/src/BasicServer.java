import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class BasicServer {
    private static final int PORT = 5000;

    // Pool de threads pour gérer plusieurs connexions clients simultanées
    private static final ExecutorService clientThreadPool = Executors.newFixedThreadPool(10);

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket (PORT)) {
            System.out.println("Serveur démarré sur le port " + PORT);

            // Boucle infinie pour accepter les connexions clients
            while (!server.isClosed()) {
                try {
                    Socket socket = server.accept(); // Nouvelle connexion client

                    // Soumet la gestion du client à un thread du pool
                    clientThreadPool.submit(new ClientHandler(socket));
                } catch (IOException e) {
                    System.err.println("Erreur de connexion  : " + e.getMessage());
                }
            }
        } catch (IOException e){
            System.err.println("Impossible de démarrer le serveur : " + e.getMessage());
        } finally {
            // Arrêt propre du pool de threads
            clientThreadPool.shutdown();
        }
    }

    // Classe interne pour gérer chaque client dans un thread séparé
    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (
                    // Flux de lecture des messages du client
                    InputStream is = clientSocket.getInputStream();
                    InputStreamReader isr = new InputStreamReader(is);
                    BufferedReader input = new BufferedReader(isr);

                    // Flux d'écriture des réponses au client
                    PrintWriter output = new PrintWriter(clientSocket.getOutputStream(), true)
            ) {
                // Affiche l'adresse IP du client connecté
                System.out.println("Nouvelle connexion client : " + clientSocket.getInetAddress());

                String message;
                // Lecture continue des messages du client
                while ((message = input.readLine()) != null) {
                    if ("bye".equalsIgnoreCase(message)) {
                        output.println("Déconnexion en cours");
                        break;
                    }

                    // Affiche et traite le message reçu
                    System.out.println("Message reçu de " + clientSocket.getInetAddress() + ": " + message);
                    output.println(message.toUpperCase());
                }
            } catch (IOException e) {
                System.err.println("Erreur de communication : " + e.getMessage());
            } finally {
                try {
                    // Fermeture de la connexion client
                    clientSocket.close();
                } catch (IOException e) {
                    System.err.println("Erreur de fermeture de socket : " + e.getMessage());
                }
            }
        }
    }
}