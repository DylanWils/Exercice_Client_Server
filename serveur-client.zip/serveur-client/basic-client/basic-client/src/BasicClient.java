import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BasicClient {
    private static final Logger LOGGER = Logger.getLogger(BasicClient.class.getName());

    private static final String HOST = "localhost";
    private static final int PORT = 5000;

     public static void main (String[] args){
         try (Socket clientSocket = new Socket(HOST, PORT);

              OutputStream os = clientSocket.getOutputStream();
              PrintWriter out = new PrintWriter(os, true);

              BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
              Scanner sc = new Scanner(System.in)) {

             System.out.println("Connecté au serveur " + HOST + ":" + PORT);

             while (true) {
                 System.out.println("Entrez votre requete : ");
                 String requete = sc.nextLine();

                 //Capitalise les messages du clients
                 String capitaleMessage = requete.toUpperCase();
                 System.out.println("Message capitalisé : " + capitaleMessage);

                 // Envoyer le message au serveur
                 out.println(requete);

                 // Vérifier la condition de sortie
                 if ("bye".equalsIgnoreCase(requete)) {
                     break;
                 }

                 // Lire et afficher la réponse du serveur
                 String serverResponse = in.readLine();
                 System.out.println("Réponse du serveur : " + serverResponse);
             }
             //fermeture
             clientSocket.close();
             System.out.println("Connexion au serveur fermée.");

         } catch (IOException ex) {
             LOGGER.log(Level.SEVERE, "Erreur de connexion au serveur", ex);
          }
     }
}
