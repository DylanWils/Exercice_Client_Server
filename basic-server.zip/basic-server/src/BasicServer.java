import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class BasicServer {
//    int a = 5000;
    public static void main(String[] toto) {
//        System.out.println("Bonjour le monde \n\n\n");
//        System.out.println("DEFITECH ");
        try{
            ServerSocket server = new ServerSocket (5000);
            System.out.println("Le serveur a demarré sur le port 5000 ");
            Socket socket = server.accept();
            InputStream is = socket.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader input = new BufferedReader(isr);
            String message = input.readLine();
            System.out.println("Message reçu : " +message);
            socket.close();


        }catch(IOException ex){
            ex.printStackTrace();
        }

    }
}
